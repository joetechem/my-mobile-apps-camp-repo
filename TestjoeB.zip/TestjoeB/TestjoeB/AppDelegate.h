//
//  AppDelegate.h
//  Testjoe B
//
//  Created by Joe seiler on Monday, July 31, 2017
//  Copyright (c) Joe seiler. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StandaloneCodeaViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) StandaloneCodeaViewController *viewController;

@end
