//
//  main.m
//  Testjoe B
//
//  Created by Joe seiler on Monday, July 31, 2017
//  Copyright (c) Joe seiler. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
